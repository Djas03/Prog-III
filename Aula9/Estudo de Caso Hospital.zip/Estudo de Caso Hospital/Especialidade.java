public class Especialidade {
    private String Nome;

    public Especialidade(String nome){
        this.Nome = nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getNome() {
        return Nome;
    }
}
