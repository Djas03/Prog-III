public class NeuroCirurgira extends Procedimento{
    
}
