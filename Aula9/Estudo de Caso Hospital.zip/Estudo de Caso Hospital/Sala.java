public class Sala {
    //Atributos
    private String nome;

    //Construtor
    public Sala(String nome){
        this.nome = nome;
    }


    //Set e get
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNome() {
        return nome;
    }

}
