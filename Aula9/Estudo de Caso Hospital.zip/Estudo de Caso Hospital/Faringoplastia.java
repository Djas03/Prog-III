public class Faringoplastia extends Procedimento{
    
}
