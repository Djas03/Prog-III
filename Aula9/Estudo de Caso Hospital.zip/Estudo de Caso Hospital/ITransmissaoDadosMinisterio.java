public interface ITransmissaoDadosMinisterio {
    public void gerarDados(){}
}
